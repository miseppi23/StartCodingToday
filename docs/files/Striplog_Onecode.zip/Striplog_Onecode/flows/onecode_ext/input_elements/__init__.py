from onecode import import_input

import_input(__file__, __name__)
