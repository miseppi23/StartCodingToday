from onecode import import_output

import_output(__file__, __name__)
