
# This file is your entry point:
# - add you Python files and folder inside this 'flows' folder
# - add your imports
# - just don't change the name of the function 'run()' nor this filename ('striplog_onecode.py')
#   and everything is gonna be ok.
#
# Remember: everything is gonna be ok in the end: if it's not ok, it's not the end.
# Alternatively, ask for help at https://github.com/deeplime-io/onecode/issues

from onecode import (
    Logger,
    checkbox,
    csv_reader,
    dropdown,
    file_output,
    file_input,
    image_output,
    text_output,
    csv_output,
    slider
)


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.gridspec import GridSpec
import matplotlib.lines as mlines


def run():
    Logger.info(
        """
        #####################################################################
        ###> Hello from Striplog_Onecode!
        ###> Fill in this run() function with something awesome!
        #####################################################################
        """
    )

    # Load collar data to get max depths for each hole
    collar_data = csv_reader('Collar','collar.csv')

    # %%
    # Print the headers of the merged table
    merged_data = csv_reader('Data','merged_data.csv')

    # %%
    print(merged_data.columns.tolist())

    # %%
    print(merged_data.head())

    # %%
    merged_data = merged_data.replace(-99, np.NaN)
    merged_data = merged_data.replace('-99', np.NaN)

    # %%
    print(merged_data.head())

    # %%
    #Assign values
    lithology=merged_data['Litologia']
    alteration=merged_data['Alteracion']

    #List the parameters to plot
    parameters = dropdown(
        'Parameters',
        ['FFEspaciamiento', 'RqdRQD', 'CUS', 'MO', 'CUFE'],
        options='$data$.columns',
        multiple=True
        )

    # %%
    cmap_parameters = {
        'PP_MINTYPE_calculadoPtXt': 'deepskyblue',
        'AG': 'dodgerblue',
        'AS': 'gold',
        'Au_ppb_BEST': 'yellowgreen',
        'ClT_kgt_BEST': 'lightcoral',
        'CO3_pct_BEST': 'mediumseagreen',
        'CUCN': 'darkcyan',
        'CUFE': 'firebrick',
        'CUS': 'indianred',
        'CUT': 'chocolate',
        'FE': 'saddlebrown',
        'FET': 'peru',
        'MO': 'mediumpurple',
        'PP_AS_PP': 'orchid',
        'PP_CC_2CSR': 'plum',
        'PP_CC_PP': 'violet',
        'PP_COV_2CSR': 'thistle',
        'PP_COV_PP': 'lavender',
        'PP_CPY_2CSR': 'slateblue',
        'PP_CPY_PP': 'mediumslateblue',
        'PY_BEST': 'royalblue',
        'S': 'steelblue',
        'S2': 'skyblue',
        'FFEspaciamiento': 'deepskyblue',
        'FFNumFracAb30Grad': 'darkorange',
        'FFNumFracAb60Grad': 'orange',
        'FFNumFracAb90Grad': 'goldenrod',
        'FFrecFrac': 'khaki',
        'FFTotalFracAbSell': 'lightgoldenrodyellow',
        'RqdRQD': 'darkorange'
    }


    # %%
    # Enumarate the lithologies
    unique_lithologies = lithology.unique()
    # Print the unique lithologies
    print("Unique lithologies in the dataset:")
    for lithology in unique_lithologies:
        print(lithology)


    # %%
    #Creation of the color map based on the different lithologies
    cmap_lith = {
        'GRAV':'tan',
        'AR':'darkgoldenrod',
        'IND':'silver',
        'SED':'gold',
        'SBR':'chocolate',
        'QFP1':'hotpink',
        'COV':'cornsilk',
        'QFP2':'coral',
        'BRXH':'antiquewhite',
        'FP':'mediumslateblue',
        'ABX1':'mediumorchid',
        'ABX2':'lightcoral',
        'ABX3':'rosybrown',
        'VOLC':'darkseagreen'
    }


    # %%
    # Enumarate the alteration
    unique_alteration = alteration.unique()
    # Print the unique lithologies
    print("Unique alteration in the dataset:")
    for alteration in unique_alteration:
        print(alteration)


    # %%
    #Creation of the color map based on the different alteration
    cmap_alt = {
        'A': 'peru',       # Arbitrary color
        'CL': 'yellowgreen',     # Arbitrary color
        'QS': 'lightsalmon',       # Arbitrary color
        'SA': 'orchid',    # Arbitrary color
        'P': 'coral',     # Arbitrary color
        'KB': 'gold',    # Arbitrary color
        'KF': 'pink'       # Arbitrary color
    }


    # %%
    holeid = dropdown('Selected holeid', 'SPD0412', options='$data$["holeid"].unique()')
    # %%
    filtered_litho_alt=merged_data[merged_data['holeid']==holeid].copy()
    filtered_parameters = merged_data[merged_data['holeid'] == holeid].copy()


    # %%
    filtered_parameters['MidDepth'] = (filtered_parameters['from'] + filtered_parameters['to']) / 2

    # %%
    # Setup figure and axes using GridSpec
    fig = plt.figure(figsize=(16, 8))  # Adjust the size as needed
    gs = GridSpec(1, len(parameters) + 3, figure=fig)
    fig.set(facecolor='none')
    # General title for the figure
    fig.suptitle(f'Drillhole {holeid}', y= 0.9, fontsize=12, fontweight='bold', fontname='Calibri', ha='left', va='bottom')
    # Plot striplog Lithology
    ax_lith = fig.add_subplot(gs[0, 0])
    ax_lith.set(facecolor = "white")
    for index, lith in filtered_litho_alt.iterrows():
        color = cmap_lith.get(lith['Litologia'], 'white')
        rect = patches.Rectangle((0, lith['from']), 1, lith['to'] - lith['from'], linewidth=1, edgecolor='None', facecolor=color)
        ax_lith.add_patch(rect)
        
    ax_lith.set_ylim([max(filtered_litho_alt['to']), min(filtered_litho_alt['from'])])
    ax_lith.set_xlim([0, 1])
    ax_lith.set_xticks([])
    ax_lith.set_ylabel('Depth (m)', fontsize=9, fontweight='bold', fontname='Calibri')
    ax_lith.set_xlabel('Lithology', fontsize=9, fontweight='bold', fontname='Calibri', labelpad=17)
    ax_lith.tick_params(axis='y', labelsize=7)  # Set tick label font size for y-axis

    # Plot striplog alteration
    ax_alt = fig.add_subplot(gs[0,1])
    ax_alt.set(facecolor="white")
    for id, alt in filtered_litho_alt.iterrows():
        color = cmap_alt.get(alt['Alteracion'], 'white')
        rect = patches.Rectangle((0, alt['from']), 1, alt['to'] - alt['from'], linewidth=1, edgecolor='None', facecolor=color)
        ax_alt.add_patch(rect)

    ax_alt.set_ylim([max(filtered_litho_alt['to']), min(filtered_litho_alt['from'])])
    ax_alt.set_xlim([0, 1])
    ax_alt.set_xticks([])
    ax_alt.set_xlabel('Alteration', fontsize=9, fontweight='bold', fontname='Calibri', labelpad=17)
    ax_alt.tick_params(axis='y', labelsize=7)  # Set tick label font size for y-axis

    #Set null value
    null_value='NaN'

    # Plot parameters
    for idx, element in enumerate(parameters, start=2):
        ax = fig.add_subplot(gs[0, idx])
        ax.set(facecolor = "white")
        data_to_plot = filtered_parameters[element].replace(null_value, 0)
        ax.plot(data_to_plot, filtered_parameters['MidDepth'], color=cmap_parameters[element], linewidth=2)
        ax.set_xlabel(f"{element} (%)", fontsize=9, fontweight='bold', fontname='Calibri')
        ax.set_ylim([max(filtered_litho_alt['to']), min(filtered_litho_alt['from'])])  # Reverse the y-axis
        ax.tick_params(axis='both', labelsize=7)  # Set tick label font size for both axes
        ax.grid(False)  # Turn off the grid
        if idx > 1:
            ax.set_yticklabels([])  # Hide y-axis labels for all but the first paramaters plot

    # Collect unique lithology and alteration from the data
    unique_lithologies = filtered_litho_alt['Litologia'].unique()
    unique_alterations = filtered_litho_alt['Alteracion'].unique()  # Assuming 'Alteracion' column exists

    # Handles for the legend
    legend_handles = []

    # Add Lithology entries to legend
    legend_handles.append(patches.Patch(color='none', label='Lithology'))  # Subtitle for lithology
    for label, color in cmap_lith.items():
        if label in unique_lithologies:
            legend_handles.append(patches.Patch(color=color, label=label))
    legend_handles.append(patches.Patch(color='none', label=''))  # For separation

    # Add Alteration entries to legend
    legend_handles.append(patches.Patch(color='none', label='Alteration'))  # Subtitle for alteration
    for label, color in cmap_alt.items():
        if label in unique_alterations:
            legend_handles.append(patches.Patch(color=color, label=label))
    legend_handles.append(patches.Patch(color='none', label=''))  # For separation

        
    # Setting the legend outside the plot area on the right
    fig.legend(handles=legend_handles, loc='center left', bbox_to_anchor=(0.85, 0.5),
            fontsize=9, edgecolor='black')
    plt.subplots_adjust(wspace=0.5) # Adjusst spacing between plots
    plt.show()
    plt.savefig(image_output('figure','figure.png', dpi=300, bbox_inches='tight', pad_inches=0.1))

