###########################################
#    !! THIS FILE IS AUTO-GENERATED !!    #
###########################################

import ast
import json
import logging
import os
import traceback
import uuid
from typing import Dict, List

import pydash
import streamlit as st
from main import main
from streamlit_image_select import image_select
from streamlit_option_menu import option_menu
from streamlit_tree_select import tree_select

from onecode import ColoredFormatter

# Imports from Elements
from pyarrow import csv as pacsv

# Init from Elements


# OneCode init
_DATA_ = {}
_placeholders = {}


def _write_logs(id: str) -> None:
    if f'__logs__{id}' in st.session_state:
        with _placeholders[id].container():
            st.markdown(
                f'''<div style="
                    background-color:black;
                    padding:1em;
                    margin-bottom:1em;
                    font-family:Source Code Pro, monospace;
                    font-size:0.8em">
                        {''.join(st.session_state[f'__logs__{id}'])}
                </div>''',
                unsafe_allow_html=True
            )


def _clear_logs(id: str) -> None:
    if f'__logs__{id}' in st.session_state:
        st.session_state[f'__logs__{id}'] = []
        _write_logs(id)


def _log(
    id: str,
    type: int,
    msg: str
) -> None:
    if id != st.session_state['__current_step_id__']:
        return

    if f'__logs__{id}' not in st.session_state:
        st.session_state[f'__logs__{id}'] = []

    color = "white"
    if type == logging.DEBUG:
        color="grey"
    elif type == logging.WARNING:
        color = "orange"
    elif type == logging.ERROR or type == logging.CRITICAL:
        color = "red"

    msg = msg.split("\n")
    st.session_state[f'__logs__{id}'].append(
        f'<span style="color:{color}">{"<br />".join(msg)}</span><br />'
    )
    _write_logs(id)


class _StreamlitLogHandler(logging.Handler):
    def __init__(
        self,
        id: str
    ):
        self._id = id
        logging.Handler.__init__(self)

    def emit(self, record):
        _log(
            self._id,
            record.levelno,
            self.format(record)
        )


def _file_to_tree(
    file_id: str,
    file_relpath: str,
    cur_path: str,
    tree: List[Dict[str, str]]
) -> None:
    path_split = file_relpath.split(os.path.sep, 1)
    path_head = path_split[0]

    if len(path_split) == 1:   # this is a file
        tree.append({
            "label": path_head,
            "value": file_id,
        })

    elif not path_head:  # means path starts with leading '/' => ignore
        _file_to_tree(file_id, path_split[1], cur_path, tree)

    else:
        node = pydash.find(tree, {"label": path_head})
        cur_path_agg = os.path.sep.join([cur_path, path_head])

        if node is None:
            n = {
                "label": path_head,
                "value": cur_path_agg,
                "children": []
            }
            tree.append(n)
            _file_to_tree(file_id, path_split[1], cur_path_agg, n["children"])

        else:
            _file_to_tree(file_id, path_split[1], cur_path_agg, node["children"])


def _show_img(path: str) -> None:
    _id = st.session_state.get('__current_step_id__')

    if not os.path.exists(path) and not os.path.isfile(path):
        st.warning(f'Invalid file path: {path}')

    elif _id is not None:
        _imgs = st.session_state.get(f'__selected_images__{_id}__', [])
        _imgs.append(path)
        st.session_state[f'__selected_images__{_id}__'] = pydash.uniq(_imgs)


with st.sidebar:
    _selected = option_menu("Main Menu", ["Striplog_Onecode"])

    # making a button despite this comment
    # https://github.com/streamlit/streamlit/issues/468#issuecomment-807166632
    if st.button('Stop Application'):
        os._exit(0)



def _ImageOutput(key=None, label=None, value=None, kind=None, tags=None, **kwargs):
    _show_img(value)


if _selected == "Striplog_Onecode":
        
    # CsvReader collar
    _file_collar = st.file_uploader(
        f'''Collar''' + ': select CSV file',
        type=['csv'],
        disabled=False,
        key='collar'
    )
    if _file_collar is not None:
        collar = pacsv.read_csv(_file_collar).to_pandas()
        if _file_collar.size // 1e6 > 200:
            st.write(
                f'File too big ({_file_collar.size // 1e6} Mo)'
                ', data has been truncated to the first 10k rows'
            )
            collar = collar[:10000]
        st.dataframe(collar)
    else:
        collar = None
    
    
    _DATA_['collar'] = collar if not (False) else None
    
    
    # CsvReader data
    _file_data = st.file_uploader(
        f'''Data''' + ': select CSV file',
        type=['csv'],
        disabled=False,
        key='data'
    )
    if _file_data is not None:
        data = pacsv.read_csv(_file_data).to_pandas()
        if _file_data.size // 1e6 > 200:
            st.write(
                f'File too big ({_file_data.size // 1e6} Mo)'
                ', data has been truncated to the first 10k rows'
            )
            data = data[:10000]
        st.dataframe(data)
    else:
        data = None
    
    
    _DATA_['data'] = data if not (False) else None
    
    
    try:
        _options_parameters = _DATA_["data"].columns
    except:
        _options_parameters = []
    
    if True: # is dropdown multiple?
        _default_parameters = [v for v in ['FFEspaciamiento', 'RqdRQD', 'CUS', 'MO', 'CUFE'] if v in _options_parameters]
    else:
        _default_parameters = pydash.find_index(_options_parameters, lambda x: x == ['FFEspaciamiento', 'RqdRQD', 'CUS', 'MO', 'CUFE'])
        _default_parameters = _default_parameters if _default_parameters >= 0 else 0
    
    # Dropdown parameters
    parameters = st.multiselect(
        '''Parameters''',
        default=_default_parameters,
        options=_options_parameters,
        disabled=False,
        key='parameters'
    )
    
    
    _DATA_['parameters'] = parameters if not (False) else None
    
    
    try:
        _options_selected_holeid = _DATA_["data"]["holeid"].unique()
    except:
        _options_selected_holeid = []
    
    if False: # is dropdown multiple?
        _default_selected_holeid = [v for v in '''SPD0412''' if v in _options_selected_holeid]
    else:
        _default_selected_holeid = pydash.find_index(_options_selected_holeid, lambda x: x == '''SPD0412''')
        _default_selected_holeid = _default_selected_holeid if _default_selected_holeid >= 0 else 0
    
    # Dropdown selected_holeid
    selected_holeid = st.selectbox(
        '''Selected holeid''',
        index=_default_selected_holeid,
        options=_options_selected_holeid,
        disabled=False,
        key='selected_holeid'
    )
    
    
    _DATA_['selected_holeid'] = selected_holeid if not (False) else None
    
    
    _step_id = 'striplog_onecode'
    st.session_state['__current_step_id__'] = _step_id
    _result = None
    _run_button = st.button('Run')
    with st.expander('Logs', True):
        _placeholders[_step_id] = st.empty()
        _write_logs(_step_id)

    if _run_button:
        with st.spinner('Running...'):
            try:
                _clear_logs(_step_id)
                handler = _StreamlitLogHandler(_step_id)
                handler.setFormatter(ColoredFormatter(False))
                _result =  main(_DATA_, _step_id, handler)
                st.info('Run finished')

                _nodes = []
                _json_output = []
                if os.path.exists(_result):
                    with open(_result) as f:
                        _json_output = pydash.sort_by(
                            json.loads(f"[{', '.join([line.rstrip() for line in f])}]"),
                            'value'
                        )

                    for _out in _json_output:
                        _filepath = _out.get('value')
                        if os.path.exists(_filepath):
                            _relpath = os.path.relpath(_filepath, os.getcwd())
                            _out['_id'] = str(uuid.uuid4())
                            _file_to_tree(_out['_id'], _relpath, '', _nodes)

                st.session_state[f'__nodes__{_step_id}__'] = _nodes
                st.session_state[f'__nodes_flat__{_step_id}__'] = _json_output

            except Exception as _e:
                st.error(
                    '\n'.join(
                        traceback.format_exception(
                            type(_e),
                            value=_e,
                            tb=_e.__traceback__
                        )
                    )
                )

    _return_select = tree_select(
        st.session_state.get(f'__nodes__{_step_id}__', []),
        expand_on_click=True,
        only_leaf_checkboxes=True,
        show_expand_all=True
    )

    _shown_files = []
    for _sel in _return_select.get('checked'):
        _n = pydash.find(
            st.session_state.get(f'__nodes_flat__{_step_id}__', []),
            {"_id": _sel}
        )
        if _n is not None:
            _shown_files.append(_n['value'])

            _fname = f"_{_n['kind']}"
            if _fname in locals():
                locals()[_fname](**pydash.omit(_n, ['_id']))

    # keep only added images still selected in the tree
    _selected_imgs = st.session_state.get(f'__selected_images__{_step_id}__', [])
    _selected_imgs = pydash.intersection(_selected_imgs, _shown_files)
    st.session_state[f'__selected_images__{_step_id}__'] = _selected_imgs

    if len(_selected_imgs) > 0:
        _img = image_select(
            label="Select an image",
            images=list(_selected_imgs),
            captions=[os.path.basename(_i) for _i in _selected_imgs],
            use_container_width=False
        )
        if _img is not None:
            # relpath allows compat with Windows
            st.image(os.path.relpath(_img), os.path.basename(_img))

