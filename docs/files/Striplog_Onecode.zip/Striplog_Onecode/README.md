## OneCode

### Dependencies
Depends on `OneCode`


### Instructions
1. Don't touch the `main.py`
2. Put your code under the `flow` folder
3. Your entry point is the `run()` function in the `runner.py` file
    (just don't change the filename not the function name)

You're good to go! Run your script by simply type in:
```bash
python main.py
```
